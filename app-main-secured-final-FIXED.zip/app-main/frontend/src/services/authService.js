import api from './api';

class AuthService {
  async adminLogin(email, password) {
    const response = await api.post('/auth/admin/login', { email, password });
    
    if (response.data.success) {
      // FIX (Bug 1): Tokens are now httpOnly cookies set by the server.
      // We only store the user object (non-sensitive) in localStorage.
      const { user } = response.data;
      localStorage.setItem('crm_user', JSON.stringify(user));
      return user;
    }
    
    throw new Error(response.data.error || 'Login failed');
  }
  
  async clientLogin(email, password, deviceId) {
    const response = await api.post('/auth/client/login', { 
      email, 
      password, 
      deviceId 
    });
    
    if (response.data.success) {
      // FIX (Bug 1): Tokens are now httpOnly cookies set by the server.
      const { user } = response.data;
      localStorage.setItem('crm_user', JSON.stringify(user));
      return user;
    }
    
    throw new Error(response.data.error || 'Login failed');
  }
  
  async logout() {
    try {
      // Cookies are sent automatically via withCredentials: true in api.js.
      // No need to read or send the refresh token manually.
      await api.post('/auth/logout', {});
    } catch (error) {
      console.error('Logout error:', error);
    } finally {
      // FIX (Bug 1): No tokens stored in localStorage — only clear user object.
      localStorage.removeItem('crm_user');
    }
  }
  
  async refreshToken() {
    // FIX (Bug 7): Refresh token is sent automatically as an httpOnly cookie.
    // No need to read it from localStorage.
    const response = await api.post('/auth/refresh', {});
    
    if (response.data.success) {
      return true;
    }
    
    throw new Error('Token refresh failed');
  }
  
  getCurrentUser() {
    try {
      const userStr = localStorage.getItem('crm_user');
      return userStr ? JSON.parse(userStr) : null;
    } catch (error) {
      return null;
    }
  }
  
  isAuthenticated() {
    // Since tokens are in httpOnly cookies we can't read them directly.
    // Use the presence of the user object as an indicator; the server will
    // reject requests with invalid/expired cookies regardless.
    return !!localStorage.getItem('crm_user');
  }

  // FIX (Bug 8): Replaced weak 32-bit hash with crypto.randomUUID().
  // The old simpleHash() had only ~4 billion possible values, causing
  // collisions on shared networks and making device binding unreliable.
  getOrCreateDeviceId() {
    let deviceId = localStorage.getItem('device_id');
    if (!deviceId) {
      // crypto.randomUUID() gives 128-bit UUID v4 — collision-free in practice.
      deviceId = (typeof crypto !== 'undefined' && crypto.randomUUID)
        ? crypto.randomUUID()
        : this._fallbackUUID();
      localStorage.setItem('device_id', deviceId);
    }
    return deviceId;
  }

  // Fallback for environments without crypto.randomUUID (old browsers)
  _fallbackUUID() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
      const r = (Math.random() * 16) | 0;
      const v = c === 'x' ? r : (r & 0x3) | 0x8;
      return v.toString(16);
    });
  }
}

export const authService = new AuthService();
